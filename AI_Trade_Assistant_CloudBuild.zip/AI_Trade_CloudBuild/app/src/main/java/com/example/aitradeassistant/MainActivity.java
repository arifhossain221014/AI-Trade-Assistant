package com.example.aitradeassistant;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.widget.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(30,40,30,30);
 TextView t=new TextView(this);t.setText("AI Trade Assistant");t.setTextSize(24);l.addView(t);
 Button s=new Button(this);s.setText("START FLOATING AI");l.addView(s); Button x=new Button(this);x.setText("STOP FLOATING AI");l.addView(x);setContentView(l);
 s.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;}Intent i=new Intent(this,FloatingService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);});
 x.setOnClickListener(v->stopService(new Intent(this,FloatingService.class)));}}
