package com.example.aitradeassistant;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;
public class FloatingService extends Service{
 WindowManager wm;View bubble;
 public void onCreate(){super.onCreate();channel();startForeground(1001,new Notification.Builder(this,"AI").setContentTitle("AI Trade Assistant").setContentText("Floating assistant is running").setSmallIcon(android.R.drawable.ic_dialog_info).build());show();}
 void channel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("AI","AI Trade Assistant",NotificationManager.IMPORTANCE_LOW));}
 void show(){if(!Settings.canDrawOverlays(this))return;final TextView b=new TextView(this);b.setText("AI");b.setTextColor(Color.WHITE);b.setGravity(17);b.setTextSize(14);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(30,120,255));g.setShape(1);b.setBackground(g);bubble=b;
 final WindowManager.LayoutParams p=new WindowManager.LayoutParams(60,60,Build.VERSION.SDK_INT>=26?2038:2002,8,-3);p.gravity=Gravity.TOP|Gravity.LEFT;p.x=20;p.y=300;wm=(WindowManager)getSystemService(WINDOW_SERVICE);wm.addView(b,p);
 b.setOnTouchListener(new View.OnTouchListener(){int sx,sy;float dx,dy;boolean moved;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){sx=p.x;sy=p.y;dx=e.getRawX();dy=e.getRawY();moved=false;return true;}if(e.getAction()==2){float xx=e.getRawX()-dx,yy=e.getRawY()-dy;if(Math.abs(xx)>8||Math.abs(yy)>8)moved=true;p.x=sx+(int)xx;p.y=sy+(int)yy;wm.updateViewLayout(b,p);return true;}if(e.getAction()==1&&!moved){panel();return true;}return true;}});}
 void panel(){final LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,18,24,18);GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(24);l.setBackground(g);
 TextView t=new TextView(this);t.setText("AI MARKET ANALYSIS");t.setTextSize(19);t.setGravity(17);t.setTypeface(null,1);l.addView(t);
 TextView a=new TextView(this);a.setText("Asset: Current TradingView Asset");a.setGravity(17);l.addView(a);
 TextView s=new TextView(this);s.setText("NO TRADE");s.setTextSize(24);s.setGravity(17);s.setTypeface(null,1);l.addView(s);
 TextView c=new TextView(this);c.setText("Confidence: --%");c.setGravity(17);l.addView(c);
 Button z=new Button(this);z.setText("ANALYZE");l.addView(z);Button q=new Button(this);q.setText("CLOSE");l.addView(q);
 final WindowManager.LayoutParams p=new WindowManager.LayoutParams(310,-2,Build.VERSION.SDK_INT>=26?2038:2002,8,-3);p.gravity=Gravity.TOP|Gravity.LEFT;p.x=40;p.y=220;wm.addView(l,p);
 z.setOnClickListener(v->{s.setText("NO TRADE");c.setText("Confidence: 0%\nLive chart data not connected");});q.setOnClickListener(v->wm.removeView(l));}
 public int onStartCommand(Intent i,int f,int id){return START_STICKY;}public void onDestroy(){if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception e){}super.onDestroy();}public IBinder onBind(Intent i){return null;}}
