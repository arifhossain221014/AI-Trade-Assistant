Phone-only build instructions
1. Upload this whole project to a GitHub repository.
2. Open the repository -> Actions -> Build APK -> Run workflow.
3. Wait for the build to finish.
4. Open the completed workflow run -> Artifacts -> AI-Trade-Assistant-APK and download the APK.
This is a debug APK for testing. It does NOT place trades automatically.
